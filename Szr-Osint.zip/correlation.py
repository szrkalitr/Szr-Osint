# correlation.py
import re

def build_correlation(username_results, email_info, phone_info, email_services=None, scraped_data=None):
    links = {
        "username_found_on": [r["platform"] for r in username_results if r["exists"]],
        "email": email_info,
        "phone": phone_info,
        "email_services": email_services,
        "scraped_data": scraped_data or {},
        "connections": [],
        "possible_matches": []
    }

    profile_names = []
    for r in username_results:
        if r["exists"] and r.get("profile"):
            p = r["profile"]
            if p.get("name"):
                profile_names.append(p["name"])


    if scraped_data:
        for platform, data in scraped_data.items():
            text_blob = " ".join(str(v) for v in data.values())
            
            if email_info and email_info.get("address"):
                if email_info["address"].lower() in text_blob.lower():
                    links["connections"].append(f"Scraper ile {platform} profilinde ana e-posta bulundu.")
          
            if phone_info and str(phone_info.get("national_number")) in text_blob:
                links["connections"].append(f"Scraper ile {platform} profilinde telefon numarası bulundu.")

    for r in username_results:
        if r["exists"] and r.get("profile"):
            p = r["profile"]
            if p.get("bio"):
                email_masks = re.findall(r'[\w\.-]+@[\w\.-]+\.\w+', p["bio"])
                phone_masks = re.findall(r'[\d\s\+\-]{7,}', p["bio"])
                for em in email_masks:
                    if email_info and email_info.get("address") and em.lower() == email_info["address"].lower():
                        links["connections"].append(f"Biyografide e-posta bulundu: {em}")
                for ph in phone_masks:
                    if phone_info and str(phone_info.get("national_number")) in ph:
                        links["connections"].append(f"Biyografide telefon bulundu: {ph}")

    if email_info and email_info.get("address"):
        email_username = email_info["address"].split("@")[0].lower()
        for name in profile_names:
            if email_username in name.lower():
                links["possible_matches"].append(f"Profil ismi '{name}' e-posta kullanıcı adıyla eşleşiyor")
            if name.lower().replace(" ", "") in email_username or name.lower().replace(" ", ".") in email_username:
                links["possible_matches"].append(f"E-posta kullanıcı adı profil ismini içeriyor: '{name}'")

    if email_services:
        for service, registered in email_services.items():
            if service.startswith("scraped_"):
                continue  
            if registered is True and service in links["username_found_on"]:
                links["connections"].append(f"E-posta ile aynı platformda kullanıcı adı da bulundu: {service}")
        
        for key, services in email_services.items():
            if key.startswith("scraped_"):
                mail = key.replace("scraped_", "")
                registered_services = [s for s, v in services.items() if v is True]
                if registered_services:
                    links["connections"].append(f"Scraper'dan bulunan {mail} e-postası şu servislere kayıtlı: {', '.join(registered_services)}")

    if not links["connections"] and not links["possible_matches"]:
        links["connections"].append("Henüz güçlü bir bağlantı kurulamadı.")
    return links