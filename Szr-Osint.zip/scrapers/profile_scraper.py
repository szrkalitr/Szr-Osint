# scrapers/profile_scraper.py
import asyncio
import re
from parsel import Selector
from config import SCRAPER_RULES

async def scrape_platform(client, username, rule):
    """Tek bir platformun HTML'ini indirip belirtilen selektörlerle veri çeker."""
    url = rule["url"].format(username)
    status, html = await client.fetch(url, method="GET")
    
    if status != 200 or not html:
        return rule["name"], None
    
    selector = Selector(text=html)
    scraped = {}
    
    for key, css_selector in rule.get("selectors", {}).items():
        value = selector.css(css_selector).get(default="").strip()
        if value:
            scraped[key] = value
    
    return rule["name"], scraped

async def scrape_all_profiles(client, username, username_results):
    """
    Sadece username_results'te exists=True olan platformları tarar.
    Dönen: { "platform_adı": {"display_name": "...", "bio": "...", ... }, ... }
    """
    
    existing_platforms = {res["platform"] for res in username_results if res.get("exists")}
    
    tasks = []
    for rule in SCRAPER_RULES:
        if rule["name"] in existing_platforms:
            tasks.append(scrape_platform(client, username, rule))
    
    results = await asyncio.gather(*tasks)
    return {name: data for name, data in results if data}