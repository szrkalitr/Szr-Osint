# report.py
def print_report(username_results, email_info, phone_info, correlation, scraped_data=None):
    print("\n" + "="*60)
    print("DERİN OSINT ANALİZ RAPORU")
    print("="*60)

    print("\n[1] Kullanıcı Adı Tarama Sonuçları:")
    for res in username_results:
        status = "✅" if res["exists"] else "❌"
        profile_str = ""
        if res.get("profile"):
            p = res["profile"]
            parts = []
            if p.get("name"):
                parts.append(f"İsim: {p['name']}")
            if p.get("bio"):
                parts.append(f"Bio: {p['bio'][:50]}...")
            if p.get("title"):
                parts.append(f"Başlık: {p['title'][:50]}")
            profile_str = " | " + ", ".join(parts) if parts else ""
        print(f"  {status} {res['platform']:15} ({res['detail']}){profile_str}")

    if scraped_data:
        print("\n[1.1] Scraper ile Çekilen Detaylar:")
        for platform, data in scraped_data.items():
            print(f"  📌 {platform}:")
            for key, value in data.items():
                print(f"      {key}: {value[:60] if len(value)>60 else value}")

    if email_info:
        print("\n[2] E‑posta Bilgisi:")
        addr = email_info.get('address')
        if addr:
            print(f"  Adres       : {addr}")
            if email_info.get('verified') is not None:
                print(f"  Doğrulama   : {'Geçerli' if email_info['verified'] else 'Geçersiz'} ({email_info.get('verify_detail')})")
            if email_info.get('breaches') is not None:
                print(f"  Veri İhlali : {email_info['breaches']} adet sızıntıda bulundu.")
            if email_info.get('source'):
                kaynak = {
                    "user_input": "Kullanıcı tarafından verildi",
                    "generated": "Kullanıcı adından üretildi",
                    "scraped": "Scraper ile bulundu"
                }.get(email_info['source'], email_info['source'])
                print(f"  Kaynak      : {kaynak}")
            if email_info.get('found_on_platforms'):
                print(f"  Bulunduğu platformlar: {', '.join(email_info['found_on_platforms'])}")
            if email_info.get('other_scraped'):
                print("  Diğer scraped e-postalar:")
                for other in email_info['other_scraped']:
                    print(f"    - {other['address']} (doğrulama: {'✅' if other['verified'] else '❌'}, bulunduğu: {', '.join(other['found_on_platforms'])})")
        if correlation.get("email_services"):
            print("\n  [E-posta ile kayıtlı servisler]:")
            for key, services in correlation["email_services"].items():
                if key.startswith("scraped_"):
                    mail = key.replace("scraped_", "")
                    print(f"    Scraped ({mail}):")
                    for service, registered in services.items():
                        if registered is True:
                            print(f"      ✅ {service}")
                        elif registered is False:
                            print(f"      ❌ {service}")
                        else:
                            print(f"      ❓ {service} (belirsiz)")
                else:
                    service_name = key
                    registered = services if isinstance(services, bool) else None
                    if registered is True:
                        print(f"    ✅ {service_name}")
                    elif registered is False:
                        print(f"    ❌ {service_name}")
                    else:
                        print(f"    ❓ {service_name} (belirsiz)")

    if phone_info:
        print("\n[3] Telefon Bilgisi:")
        print(f"  Numara      : +{phone_info.get('country_code')} {phone_info.get('national_number')}")
        print(f"  Operatör    : {phone_info.get('carrier')}")
        print(f"  Bölge       : {phone_info.get('region')}")
        print(f"  Zaman Dilimi: {phone_info.get('timezone')}")

    print("\n[4] Çapraz Korelasyon:")
    for conn in correlation["connections"]:
        print(f"  🔗 {conn}")
    if correlation.get("possible_matches"):
        print("  Olası eşleşmeler:")
        for match in correlation["possible_matches"]:
            print(f"    💡 {match}")

    print("\n" + "="*60)