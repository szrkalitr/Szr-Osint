# main.py
import asyncio
import argparse
import re
from core.http_client import AsyncOSINTClient
from scanners.username import scan_username
from scanners.email import verify_email, check_breaches, generate_emails, scan_email_services
from scanners.phone import analyze_phone
from scrapers.profile_scraper import scrape_all_profiles  # 🆕
from correlation import build_correlation
from report import print_report

def szr_banner():
    banner = r"""
   _____ ______  _____  
  / ____|___  / |  __ \ 
 | (___    / /  | |__) |
  \___ \  / /   |  _  / 
  ____) |/ /__  | | \ \ 
 |_____//_____| |_|  \_\
"""
    print(banner)
    print("Derin OSINT & İlişkilendirme Aracı - v1.1 (Scraper destekli)\n")

async def main():
    parser = argparse.ArgumentParser(
        description="SZR - Derin OSINT Analiz Aracı",
        epilog="Yalnızca kendi hesaplarınız veya izin aldığınız hedefler üzerinde kullanın."
    )
    parser.add_argument("-u", "--username", required=True, help="Hedef kullanıcı adı")
    parser.add_argument("-e", "--email", help="Hedef e-posta adresi")
    parser.add_argument("-p", "--phone", help="Hedef telefon numarası (örn: +905551234567)")
    parser.add_argument("--generate-emails", action="store_true",
                        help="Kullanıcı adından olası e-postaları üret ve doğrula")
    parser.add_argument("--scan-services", action="store_true",
                        help="E-postanın kayıtlı olduğu servisleri tara (Holehe benzeri)")
    parser.add_argument("--no-scraper", action="store_true",
                        help="Scraper'ı devre dışı bırak (sadece API/status kontrolleri)")
    parser.add_argument("--concurrency", type=int, default=15,
                        help="Eşzamanlı istek sayısı (varsayılan: 15)")
    parser.add_argument("--rate", type=int, default=12,
                        help="Saniyede maksimum istek (varsayılan: 12)")
    args = parser.parse_args()

    szr_banner()

    username = args.username
    email_input = args.email
    phone_input = args.phone
    generate_flag = args.generate_emails
    scan_services = args.scan_services
    use_scraper = not args.no_scraper

    if not email_input and not generate_flag and not use_scraper:
        print("[!] E-posta verilmedi, otomatik üretim seçilmedi ve scraper kapalı. Sadece kullanıcı adı ve telefon (varsa) analiz edilecek.\n")

    async with AsyncOSINTClient(concurrency=args.concurrency, rate_per_sec=args.rate) as client:
        print(f"[*] Kullanıcı adı taranıyor: {username}")
        user_results = await scan_username(client, username)

        # ---------- 1. E-POSTA BİLGİSİ (Kullanıcı girdisi veya üretim) ----------
        email_info = None
        email_services = None

        if email_input:
            print(f"[*] E-posta doğrulanıyor: {email_input}")
            verified, detail = await verify_email(email_input)
            breaches = None
            if verified:
                breaches, _ = await check_breaches(client, email_input)
            email_info = {
                "address": email_input,
                "verified": verified,
                "verify_detail": detail,
                "breaches": breaches,
                "generated": False,
                "source": "user_input"
            }
            if scan_services and verified:
                print("[*] E-posta ile kayıtlı servisler taranıyor...")
                email_services = await scan_email_services(client, email_input)

        elif generate_flag:
            print("[*] Olası e-postalar üretiliyor ve doğrulanıyor...")
            generated = generate_emails(username)
            valid_emails = []
            for email in generated:
                v, d = await verify_email(email)
                if v:
                    breaches, _ = await check_breaches(client, email)
                    valid_emails.append((email, breaches, d))
                    print(f"    Geçerli: {email}")
                else:
                    print(f"    Geçersiz: {email} ({d})")
            if valid_emails:
                chosen = valid_emails[0]
                email_info = {
                    "address": chosen[0],
                    "verified": True,
                    "verify_detail": chosen[2],
                    "breaches": chosen[1],
                    "generated": True,
                    "other_valid": [e[0] for e in valid_emails[1:]],
                    "source": "generated"
                }
                if scan_services:
                    print("[*] E-posta ile kayıtlı servisler taranıyor...")
                    email_services = await scan_email_services(client, chosen[0])
            else:
                print("[!] Hiçbir e-posta geçerli değil.")
                email_info = {"address": None, "verified": False, "detail": "Hiçbiri geçerli değil", "generated": True}
                
        scraped_data = {}
        if use_scraper:
            print("[*] Scraper ile profil detayları çekiliyor (biyografi, lokasyon, vb.)...")
            scraped_data = await scrape_all_profiles(client, username, user_results)
            if scraped_data:
                print(f"[+] {len(scraped_data)} platformdan detay alındı.")
            else:
                print("[!] Hiçbir platformdan scraper verisi alınamadı.")


        scraped_emails = set()
        if scraped_data:
            for platform, data in scraped_data.items():
               
                text_blob = " ".join(str(v) for v in data.values())
                found = re.findall(r'[\w\.-]+@[\w\.-]+\.\w+', text_blob)
                if found:
                    scraped_emails.update(found)
                    print(f"    [{platform}] bulunan e-posta: {', '.join(found)}")

        if scraped_emails:
            existing_email = email_info.get("address") if email_info else None
            for mail in scraped_emails:
                if mail == existing_email:
                    continue  
                
                print(f"[*] Scraper'dan bulunan e-posta doğrulanıyor: {mail}")
                verified, detail = await verify_email(mail)
                breaches = None
                if verified:
                    breaches, _ = await check_breaches(client, mail)
                
              
                if verified and scan_services:
                    print(f"[*] Bulunan mail için servis taraması başlatılıyor: {mail}")
                    services = await scan_email_services(client, mail)

                    if email_services is None:
                        email_services = {}
                    
                    email_services[f"scraped_{mail}"] = services

                
                if not email_info or not email_info.get("address"):
                    email_info = {
                        "address": mail,
                        "verified": verified,
                        "verify_detail": detail,
                        "breaches": breaches,
                        "generated": False,
                        "source": "scraped",
                        "found_on_platforms": [p for p, d in scraped_data.items() if mail in " ".join(str(v) for v in d.values())]
                    }
                else:
                    
                    if "other_scraped" not in email_info:
                        email_info["other_scraped"] = []
                    email_info["other_scraped"].append({
                        "address": mail,
                        "verified": verified,
                        "detail": detail,
                        "breaches": breaches,
                        "found_on_platforms": [p for p, d in scraped_data.items() if mail in " ".join(str(v) for v in d.values())]
                    })

        
        phone_info = None
        if phone_input:
            print(f"[*] Telefon analiz ediliyor: {phone_input}")
            phone_data = await analyze_phone(phone_input)
            if phone_data:
                phone_info = phone_data
            else:
                print("[!] Geçersiz numara veya bilgi alınamadı.")

        
        correlation = build_correlation(user_results, email_info, phone_info, email_services, scraped_data)
        print_report(user_results, email_info, phone_info, correlation, scraped_data)

if __name__ == "__main__":
    asyncio.run(main())