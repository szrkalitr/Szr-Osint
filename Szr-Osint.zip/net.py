import aiohttp
import asyncio

async def test():
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get("https://api.github.com") as resp:
                print("Status:", resp.status)
                print("Text:", await resp.text())
    except Exception as e:
        print("Hata:", type(e).__name__, str(e))

asyncio.run(test())
