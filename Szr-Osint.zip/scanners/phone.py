# scanners/phone.py
import asyncio
import phonenumbers
from phonenumbers import carrier, geocoder, timezone

def parse_phone_sync(number):
    try:
        p = phonenumbers.parse(number, None)
        if not phonenumbers.is_valid_number(p):
            return None
        return {
            "country_code": p.country_code,
            "national_number": p.national_number,
            "carrier": carrier.name_for_number(p, "en") or "Bilinmiyor",
            "region": geocoder.description_for_number(p, "en") or "Bilinmiyor",
            "timezone": timezone.time_zones_for_number(p)
        }
    except Exception:
        return None

async def analyze_phone(number):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, parse_phone_sync, number)