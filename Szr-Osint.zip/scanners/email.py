# scanners/email.py
import asyncio
import hashlib
import aiosmtplib
from dns import resolver
from config import EMAIL_SERVICES

async def get_mx_record(domain):
    loop = asyncio.get_running_loop()
    try:
        answers = await loop.run_in_executor(None, resolver.resolve, domain, 'MX')
        mx_records = sorted([(r.preference, str(r.exchange).rstrip('.')) for r in answers])
        if mx_records:
            return mx_records[0][1]
    except Exception:
        pass
    fallbacks = {
        "gmail.com": "gmail-smtp-in.l.google.com",
        "outlook.com": "outlook-com.olc.protection.outlook.com",
        "hotmail.com": "hotmail-com.olc.protection.outlook.com",
        "yahoo.com": "mta5.am0.yahoodns.net"
    }
    return fallbacks.get(domain, None)

async def verify_email(email):
    if '@' not in email:
        return False, "Geçersiz format"
    domain = email.split('@')[-1]
    mx_host = await get_mx_record(domain)
    if not mx_host:
        return False, "MX sunucusu bulunamadı"
    try:
        async with aiosmtplib.SMTP(hostname=mx_host, port=25, timeout=10) as smtp:
            await smtp.ehlo()
            await smtp.mail('test@example.com')
            code, message = await smtp.rcpt(email)
            return (code == 250), f"SMTP {code} {message}"
    except Exception as e:
        return False, str(e)

async def check_breaches(client, email):
    sha1 = hashlib.sha1(email.encode()).hexdigest().upper()
    prefix, suffix = sha1[:5], sha1[5:]
    url = f"https://api.pwnedpasswords.com/range/{prefix}"
    status, text = await client.fetch(url)
    if status != 200:
        return None, "API hatası"
    for line in text.splitlines():
        if ':' in line:
            h, count = line.split(':')
            if h == suffix:
                return int(count), None
    return 0, None

def generate_emails(username, domains=None):
    if domains is None:
        domains = ["gmail.com", "outlook.com", "hotmail.com", "yahoo.com"]
    return [f"{username}@{d}" for d in domains]

async def check_email_service(client, email, service):
    name, url_tpl, method, post_data, success_str, fail_str = service
    url = url_tpl.format(email)
    data = None
    headers = {}
    if post_data:
        data = post_data.format(email)
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    status, text = await client.fetch(url, method=method, headers=headers, data=data)
    if status is None:
        return name, False
    text_lower = text.lower()
    if success_str.lower() in text_lower:
        return name, True
    elif fail_str.lower() in text_lower:
        return name, False
    else:
        return name, None

async def scan_email_services(client, email):
    tasks = [check_email_service(client, email, srv) for srv in EMAIL_SERVICES]
    results = await asyncio.gather(*tasks)
    return {name: res for name, res in results}