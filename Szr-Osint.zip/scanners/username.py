# scanners/username.py
import asyncio
import re
import json
from config import PLATFORMS

async def check_platform(client, username, platform):
    url = platform["url"].format(username)
    headers = platform.get("headers", {})
    status, text = await client.fetch(url, method=platform["method"], headers=headers)

    if status is None:
        return {"platform": platform["name"], "exists": False, "detail": "Connection error", "profile": None}

    exists = False
    if platform["check_type"] == "status":
        exists = (status == platform["exists_status"])
    elif platform["check_type"] == "string":
        not_found = platform["not_found_string"].lower()
        exists = (status == platform["exists_status"]) and (not_found not in text.lower())
    elif platform["check_type"] == "json_list":
        try:
            data = json.loads(text)
            exists = isinstance(data, list) and len(data) > 0
        except:
            exists = False
    else:
        exists = False

    profile_info = None
    if exists and platform.get("extract_details"):
        profile_info = await extract_profile_details(platform, text)

    return {"platform": platform["name"], "exists": exists, "detail": f"HTTP {status}", "profile": profile_info}

async def extract_profile_details(platform, text):
    details = {}
    dtype = platform.get("details_type")
    if dtype == "json":
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                details["name"] = data.get("name") or data.get("login") or data.get("username")
                details["bio"] = data.get("bio") or data.get("description")
                details["avatar_url"] = data.get("avatar_url") or data.get("avatar")
            elif isinstance(data, list) and len(data) > 0:
                user = data[0]
                details["name"] = user.get("name") or user.get("username")
                details["bio"] = user.get("bio") or user.get("description")
                details["avatar_url"] = user.get("avatar_url") or user.get("avatar")
        except:
            pass
    elif dtype == "regex":
        title_match = re.search(r"<title>(.*?)</title>", text, re.IGNORECASE)
        if title_match:
            title = title_match.group(1)
            details["title"] = title
    return details

async def scan_username(client, username):
    tasks = [check_platform(client, username, p) for p in PLATFORMS]
    results = await asyncio.gather(*tasks)
    return results