# config.py
PLATFORMS = [
    {
        "name": "GitHub",
        "url": "https://api.github.com/users/{}",
        "method": "GET",
        "check_type": "status",
        "exists_status": 200,
        "headers": {"Accept": "application/vnd.github.v3+json"},
        "extract_details": True,
        "details_type": "json"
    },
    {
        "name": "GitLab",
        "url": "https://gitlab.com/api/v4/users?username={}",
        "method": "GET",
        "check_type": "json_list",
        "exists_status": 200,
        "extract_details": True,
        "details_type": "json"
    },
    {
        "name": "Twitter",
        "url": "https://twitter.com/{}",
        "method": "GET",
        "check_type": "string",
        "not_found_string": "This account doesn’t exist",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "Reddit",
        "url": "https://www.reddit.com/user/{}",
        "method": "GET",
        "check_type": "string",
        "not_found_string": "page not found",
        "exists_status": 200,
        "extract_details": True,
        "details_type": "regex"
    },
    {
        "name": "YouTube",
        "url": "https://www.youtube.com/@{}",
        "method": "GET",
        "check_type": "string",
        "not_found_string": "This page isn't available",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "Instagram",
        "url": "https://www.instagram.com/{}/",
        "method": "GET",
        "check_type": "string",
        "not_found_string": "Sorry, this page isn't available.",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "Pinterest",
        "url": "https://www.pinterest.com/{}/",
        "method": "GET",
        "check_type": "status",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "HackerNews",
        "url": "https://news.ycombinator.com/user?id={}",
        "method": "GET",
        "check_type": "string",
        "not_found_string": "No such user",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "Medium",
        "url": "https://medium.com/@{}",
        "method": "GET",
        "check_type": "status",
        "exists_status": 200,
        "extract_details": True,
        "details_type": "regex"
    },
    {
        "name": "dev.to",
        "url": "https://dev.to/{}",
        "method": "GET",
        "check_type": "status",
        "exists_status": 200,
        "extract_details": True,
        "details_type": "regex"
    },
    {
        "name": "Keybase",
        "url": "https://keybase.io/{}",
        "method": "GET",
        "check_type": "status",
        "exists_status": 200,
        "extract_details": True,
        "details_type": "regex"
    },
    {
        "name": "Vimeo",
        "url": "https://vimeo.com/{}",
        "method": "GET",
        "check_type": "status",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "Twitch",
        "url": "https://www.twitch.tv/{}",
        "method": "GET",
        "check_type": "string",
        "not_found_string": "Sorry. Unless you’ve got a time machine",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "Steam",
        "url": "https://steamcommunity.com/id/{}",
        "method": "GET",
        "check_type": "string",
        "not_found_string": "The specified profile could not be found",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "Spotify",
        "url": "https://open.spotify.com/user/{}",
        "method": "GET",
        "check_type": "status",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "Patreon",
        "url": "https://www.patreon.com/{}",
        "method": "GET",
        "check_type": "status",
        "exists_status": 200,
        "extract_details": False
    },
    {
        "name": "ProductHunt",
        "url": "https://www.producthunt.com/@{}",
        "method": "GET",
        "check_type": "status",
        "exists_status": 200,
        "extract_details": False
    }
]


EMAIL_SERVICES = [
    
    ("Twitter", "https://api.twitter.com/i/users/email_available.json?email={}", "GET", None, "false", "true"),
    ("Instagram", "https://www.instagram.com/api/v1/web/accounts/web_create_ajax/attempt/", "POST", "email={}", "email_is_taken", "email_is_valid"),
    ("Facebook", "https://www.facebook.com/api/graphql/", "POST", "email={}", "true", "false"),
    ("TikTok", "https://www.tiktok.com/api/v1/auth/email/check/", "POST", "email={}", "is_registered", "is_available"),
    ("Pinterest", "https://www.pinterest.com/_ngjs/resource/EmailExistsResource/get/", "GET", None, "true", "false"),
    ("Snapchat", "https://accounts.snapchat.com/accounts/email_exists", "POST", "email={}", "exists", "available"),
    ("Reddit", "https://www.reddit.com/api/check_username.json?email={}", "GET", None, "true", "false"),
    ("Tumblr", "https://www.tumblr.com/svc/account/register/check_email", "POST", "email={}", "taken", "available"),
    
    
    ("LinkedIn", "https://www.linkedin.com/checkpoint/lg/login-submit", "POST", "email={}", "error", "success"),
    ("GitHub", "https://api.github.com/user/email/{}", "GET", None, "true", "false"),
    ("GitLab", "https://gitlab.com/api/v4/users?email={}", "GET", None, "true", "false"),
    ("StackOverflow", "https://stackoverflow.com/users/email/exists", "POST", "email={}", "exists", "available"),
    
  
    ("Gravatar", "https://en.gravatar.com/{}.json", "GET", None, "profile", "not found"),
    ("ProtonMail", "https://api.protonmail.ch/pks/lookup?op=index&search={}", "GET", None, "info", "not found"),
    
    
    ("Amazon", "https://www.amazon.com/ap/email/validate", "POST", "email={}", "valid", "invalid"),
    ("Etsy", "https://www.etsy.com/api/v2/ajax/email/check", "POST", "email={}", "taken", "available"),
    ("Spotify", "https://www.spotify.com/api/signup/validate", "POST", "email={}", "is_registered", "false"),
    ("Netflix", "https://www.netflix.com/api/email/check", "POST", "email={}", "exists", "not_exists"),
    
    ("Adobe", "https://auth.services.adobe.com/signin/v2/users/accounts", "POST", "username={}", "error", "unavailable"),
    ("Imgur", "https://imgur.com/signin/ajax_email_available", "POST", "email={}", "false", "true"),
    ("Patreon", "https://www.patreon.com/api/auth/check_email", "POST", "email={}", "taken", "available"),
    ("Disqus", "https://disqus.com/api/3.0/users/checkUsername.json?email={}", "GET", None, "true", "false"),
    ("Vimeo", "https://vimeo.com/api/v2/user/email_exists?email={}", "GET", None, "true", "false"),
    ("WordPress", "https://public-api.wordpress.com/rest/v1.1/users/exists?email={}", "GET", None, "true", "false"),
    ("Medium", "https://medium.com/api/v1/users/email/check", "POST", "email={}", "taken", "available"),
    ("Dev.to", "https://dev.to/api/users/check_email", "POST", "email={}", "taken", "available"),
    
    ("OkCupid", "https://www.okcupid.com/signup/email-check", "POST", "email={}", "taken", "available"),
    ("Eventbrite", "https://www.eventbrite.com/api/v3/users/email_check/?email={}", "GET", None, "true", "false"),
    ("Codecademy", "https://www.codecademy.com/api/v1/users/email_check?email={}", "GET", None, "true", "false"),
    ("Udemy", "https://www.udemy.com/api-2.0/users/email-check/?email={}", "GET", None, "exists", "available"),
    ("Coursera", "https://www.coursera.org/api/emailExists", "POST", "email={}", "exists", "available"),
    
    ("PayPal", "https://www.paypal.com/api/account/email/check", "POST", "email={}", "true", "false"),
    ("Stripe", "https://api.stripe.com/v1/accounts/email/check", "POST", "email={}", "exists", "available"),
    
    ("LastPass", "https://lastpass.com/email_check.php", "POST", "email={}", "exists", "available"),
    ("Flickr", "https://www.flickr.com/signin/check/email", "POST", "email={}", "exists", "available"),
    ("SoundCloud", "https://soundcloud.com/signup/check_email", "POST", "email={}", "taken", "available"),
    ("Twitch", "https://www.twitch.tv/api/v1/users/email/check", "POST", "email={}", "true", "false"),
    ("Steam", "https://store.steampowered.com/account/email/check", "POST", "email={}", "exists", "available"),
    ("EpicGames", "https://www.epicgames.com/api/email/check", "POST", "email={}", "exists", "available"),
]
SCRAPER_RULES = [
    {
        "name": "GitHub",
        "url": "https://github.com/{}",
        "selectors": {
            "display_name": "span.p-nickname::text",
            "bio": "div.p-nickname + div::text",  # yaklaşık
            "location": "li[itemprop='homeLocation'] span::text",
            "company": "li[itemprop='worksFor'] span::text"
        }
    },
    {
        "name": "Reddit",
        "url": "https://www.reddit.com/user/{}",
        "selectors": {
            "display_name": "span[data-testid='username']::text",
            "bio": "div[data-testid='bio']::text",
            "karma": "span[data-testid='karma']::text"
        }
    },
    {
        "name": "Medium",
        "url": "https://medium.com/@{}",
        "selectors": {
            "display_name": "h1.glass::text",
            "bio": "div.glass p::text"
        }
    },
    {
        "name": "dev.to",
        "url": "https://dev.to/{}",
        "selectors": {
            "display_name": "h1.crayons-title::text",
            "bio": "div.crayons-card p::text"
        }
    },
    {
        "name": "Keybase",
        "url": "https://keybase.io/{}",
        "selectors": {
            "display_name": "h1.display-name::text",
            "bio": "div.bio::text",
            "location": "span.location::text"
        }
    },
    
]