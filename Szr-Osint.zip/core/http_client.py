# core/http_client.py
import aiohttp
import asyncio
from aiolimiter import AsyncLimiter
from aiohttp.resolver import AsyncResolver  

class AsyncOSINTClient:
    def __init__(self, concurrency=10, rate_per_sec=10):
        self.sem = asyncio.Semaphore(concurrency)
        self.limiter = AsyncLimiter(rate_per_sec, 1)
        self.session = None
        self.default_headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            )
        }

    async def __aenter__(self):
        
        resolver = AsyncResolver(nameservers=["8.8.8.8", "1.1.1.1"])
        
        connector = aiohttp.TCPConnector(
            limit=0,
            force_close=True,
            enable_cleanup_closed=True,
            resolver=resolver,        
            ssl=False                 
        )
        timeout = aiohttp.ClientTimeout(
            total=30,      
            connect=10     
        self.session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers=self.default_headers
        )
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.session.close()

    async def fetch(self, url, method="GET", headers=None, **kwargs):
        async with self.sem:
            await self.limiter.acquire()
            req_headers = self.default_headers.copy()
            if headers:
                req_headers.update(headers)
            try:
                async with self.session.request(
                    method, url, headers=req_headers, **kwargs
                ) as resp:
                    text = await resp.text()
                    return resp.status, text
            except asyncio.TimeoutError:
                return None, "Timeout"
            except aiohttp.ClientError as e:
                return None, f"ClientError: {str(e)}"
            except Exception as e:
                return None, str(e)